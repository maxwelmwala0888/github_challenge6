# main.py
from fastapi import FastAPI, UploadFile, File, Form, Depends
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
import os, shutil

from backend.database import Base, SessionLocal, engine
from backend.models import Project, BeforeAfter, Comment

# ----------------------------
# Create tables in DB
# ----------------------------
Base.metadata.create_all(bind=engine)

# ----------------------------
# FastAPI app
# ----------------------------
app = FastAPI()

# ----------------------------
# Mount static folders
# ----------------------------
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")
app.mount("/static", StaticFiles(directory="frontend"), name="static")  # frontend folder for index.html, CSS, JS

# ----------------------------
# DB session dependency
# ----------------------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ----------------------------
# Startup: create necessary folders
# ----------------------------
@app.on_event("startup")
def create_upload_folders():
    # Upload folders
    for folder in ["uploads/completed", "uploads/progress", "uploads/before", "uploads/after"]:
        os.makedirs(folder, exist_ok=True)
    # Frontend folder
    os.makedirs("frontend", exist_ok=True)

# ----------------------------
# Serve index.html at root
# ----------------------------
@app.get("/", response_class=HTMLResponse)
async def read_index():
    file_path = os.path.join("frontend", "index.html")
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            html_content = f.read()
        return HTMLResponse(content=html_content)
    else:
        return HTMLResponse(content="<h1>index.html not found!</h1>")

# ----------------------------
# Upload project endpoint
# ----------------------------
@app.post("/upload/project")
async def upload_project(
    title: str = Form(...),
    location: str = Form(...),
    description: str = Form(...),
    section: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    folder = os.path.join("uploads", section)
    os.makedirs(folder, exist_ok=True)

    # Sanitize filename and avoid path traversal
    safe_filename = os.path.basename(file.filename)
    path = os.path.join(folder, safe_filename)

    with open(path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    # ✅ Normalised web path
    image_path = "/" + path.replace("\\", "/")

    project = Project(
        title=title,
        location=location,
        description=description,
        section=section,
        image_path=image_path
    )

    try:
        db.add(project)
        db.commit()
        db.refresh(project)
    except Exception as e:
        db.rollback()
        return {"error": str(e)}

    # ✅ Return the image_path so the frontend can use it immediately
    return {"message": "Project uploaded", "image_path": image_path, "id": project.id}


@app.post("/upload/comment")
async def add_comment(
    name: str = Form(...),
    email: str = Form(...),
    comment: str = Form(...),
    db: Session = Depends(get_db)
):
    new_comment = Comment(name=name, email=email, comment=comment)
    db.add(new_comment)
    db.commit()
    db.refresh(new_comment)  # ✅ ensures we have the generated id
    return {"status": "success", "id": new_comment.id}

@app.get("/projects/{section}")
async def get_projects(section: str, db: Session = Depends(get_db)):
    projects = db.query(Project).filter(Project.section == section).all()
    return [
        {
            "title": p.title,
            "location": p.location,
            "description": p.description,
            "image_path": p.image_path
        }
        for p in projects
    ]

# ADD THIS TO main.py
@app.get("/api/projects")
async def get_projects(db: Session = Depends(get_db)):
    projects = db.query(Project).all()
    # This sends the list to the frontend
    return projects

@app.post("/upload/comment")
async def add_comment(
    name: str = Form(...),
    email: str = Form(...),
    comment: str = Form(...),
    db: Session = Depends(get_db)
):
    new_comment = Comment(name=name, email=email, comment=comment)
    db.add(new_comment)
    db.commit()
    return {"status": "success", "id": new_comment.id}

@app.get("/comments")
async def get_comments(db: Session = Depends(get_db)):
    comments = db.query(Comment).order_by(Comment.id.desc()).all()
    return [
        {
            "id": c.id,
            "name": c.name,
            "email": c.email,
            "comment": c.comment,
            "created_at": c.created_at.isoformat() if c.created_at else None
        }
        for c in comments
    ]



# ----------------------------
# Debug
# ----------------------------
print("DEBUG: app object exists:", 'app' in globals())
